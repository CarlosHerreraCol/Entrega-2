from setuptools import setup, find_packages

setup(
    name="cliente_paquete",
    version="0.1",
    packages=find_packages(),
    description="Paquete para modelar clientes en una página de compras",
    author="Carlos Herrera",
    author_email="carlosherreraardila@gmail.com",
)